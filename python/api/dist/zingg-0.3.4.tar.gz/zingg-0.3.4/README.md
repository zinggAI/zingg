## About zingg package

Zingg Python APIs for entity resolution, record linkage, data mastering and deduplication
[Zingg.AI](https://www.zingg.ai) 

# requirement
python 3.6+; spark 3.1.2

# Installation

```
pip install zingg
``` 

